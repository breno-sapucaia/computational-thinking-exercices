
public class Teste {

	public static void main(String[] args) {
		ContaCorrente cc = new ContaCorrente();
		cc.setSaldo(9000);
		cc.exibirSaldo();
		cc.setLimiteCredito(100);
		
		
		ContaPoupanca cp = new ContaPoupanca();
		System.out.println(cp.getSaldo());
		cp.depositar(20);
		System.out.println(cp.getSaldo());
		cp.sacar(5);
		System.out.println(cp.getSaldo());
		
	}

}
