
public class ContaPoupanca extends ContaBancaria{
	private double taxaJuros;
	
	public void atualizarSaldo(){
		super.setSaldo(super.getSaldo() + (super.getSaldo()*(this.taxaJuros/100))); 
	}

	public double getTaxaJuros() {
		return taxaJuros;
	}

	public void setTaxaJuros(double taxaJuros) {
		this.taxaJuros = taxaJuros;
	}
	
	
}
