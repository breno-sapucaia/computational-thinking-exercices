package br.com.empresa.cadastro.entidades;

import java.util.Scanner;

public class Tesste {

	public static void main(String[] args) {
		Scanner read = new Scanner(System.in);
		System.out.println("digite o nome");
		String nome= read.nextLine();
		System.out.println("digite o titulo");
		String titulo = read.nextLine();
		Cliente cli = new Cliente(titulo,nome);
		System.out.println(cli.exibirNomeFormatado());

	}

}
