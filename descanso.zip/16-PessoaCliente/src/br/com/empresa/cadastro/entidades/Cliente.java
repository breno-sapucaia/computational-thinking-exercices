package br.com.empresa.cadastro.entidades;

public class Cliente extends Pessoa{
	private String titulo;
	
	
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	public String exibirNomeFormatado() {
		return this.getTitulo().toUpperCase()+" - "+ super.exibirNomeFormatado().toUpperCase();
	}

	public Cliente(String titulo, String nome) {
		super(nome);
		this.titulo = titulo;
	}
}
