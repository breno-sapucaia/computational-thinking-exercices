
public class Testes {

	public static void main(String[] args) {
		Tecnologo tec = new Tecnologo();
		tec.setDescricao("Curso de 2 anos de dura��o");
		tec.setPeriodo(4);
		System.out.println(tec.exibirMedia(5.5, 7.0));
		tec.calcularMensalidade(1.5);
		System.out.println(tec.getTudo());
		
		
		Bacharelado bac = new Bacharelado();
		bac.setDescricao("curso de 4 anos");
		bac.setPeriodo(8);
		System.out.println(bac.exibirMedia(2.0,5.0));
		bac.setProjetoConclusao("Filosofia das brabuleta");
		bac.setCargaHorariaEstagio(20);
		bac.calcularMensalidade(1.5);
		System.out.println(bac.getTudo());
		
		Medio medio = new Medio();
		medio.setDescricao("Curso t�cnico de 3 anos de dura��o");
		medio.setPeriodo(6);
		System.out.println(medio.exibirMedia(8.0, 2.0, 4.0, 6.0));
		medio.setTipo("T�cnico");
		medio.calcularMensalidade(1.5);
		System.out.println(medio.getTudo());
	}

}
