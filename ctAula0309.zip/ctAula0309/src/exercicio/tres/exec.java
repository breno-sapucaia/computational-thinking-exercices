package exercicio.tres;

public class exec {

	public static void main(String[] args) {
		System.out.println(Main.VerifyAsc(50, 51 ));

	}

}
