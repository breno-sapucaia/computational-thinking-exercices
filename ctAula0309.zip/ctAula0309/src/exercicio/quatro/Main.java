package exercicio.quatro;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(notas.gimme(5, 5, 5, "A"));
		System.out.println(notas.gimme(5, 5, 5, "P"));
	}

}
