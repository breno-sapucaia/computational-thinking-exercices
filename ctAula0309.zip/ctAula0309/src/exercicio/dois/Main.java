package exercicio.dois;

public class Main {

	public static void main(String[] args) {
		System.out.println(Converter.Converter(3600)); 
		
	}

}
