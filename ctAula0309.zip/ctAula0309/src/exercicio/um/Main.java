package exercicio.um;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Calculadora.Somar(1, 1));
		
		System.out.println(Calculadora.Dividir(1, 0));
		
		System.out.println(Calculadora.Multiplicar(3, 5));
		
		System.out.println(Calculadora.Subtrair(10, 8));
	}

}
